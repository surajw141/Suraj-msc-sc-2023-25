#A program to add two numbers

def my_cool_addition(a,b):return a+b

print(my_cool_addition(int(input("Give me number")), int(input("Give me another number"))))

