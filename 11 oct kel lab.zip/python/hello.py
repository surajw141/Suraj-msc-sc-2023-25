name='Suraj'
surname='Waghmare'

print(name+surname)

