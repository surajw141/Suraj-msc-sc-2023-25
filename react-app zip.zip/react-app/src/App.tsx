import ListGroup from "./component/ListGroup"; 

function App(){
  return <div><ListGroup /></div>;
}
export default App;